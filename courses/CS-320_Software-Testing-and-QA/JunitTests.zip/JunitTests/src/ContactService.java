import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;
    
    public ContactService() {
        contacts = new HashMap<>();
    }
    
    public boolean addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            return false;
        }
        contacts.put(contact.getContactId(), contact);
        return true;
    }
    
    public boolean deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            return false;
        }
        contacts.remove(contactId);
        return true;
    }
    
    public boolean updateFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setFirstName(firstName);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public boolean updateLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setLastName(lastName);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public boolean updatePhone(String contactId, String phone) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setPhone(phone);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public boolean updateAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setAddress(address);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
    
    public int getContactCount() {
        return contacts.size();
    }
}
