import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;
    
    public TaskService() {
        tasks = new HashMap<>();
    }
    
    public boolean addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            return false;
        }
        tasks.put(task.getTaskId(), task);
        return true;
    }
    
    public boolean deleteTask(String taskId) {
        if (taskId == null || !tasks.containsKey(taskId)) {
            return false;
        }
        tasks.remove(taskId);
        return true;
    }
    
    public boolean updateName(String taskId, String name) {
        Task task = tasks.get(taskId);
        if (task == null) {
            return false;
        }
        try {
            task.setName(name);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public boolean updateDescription(String taskId, String description) {
        Task task = tasks.get(taskId);
        if (task == null) {
            return false;
        }
        try {
            task.setDescription(description);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
    
    public int getTaskCount() {
        return tasks.size();
    }
}
