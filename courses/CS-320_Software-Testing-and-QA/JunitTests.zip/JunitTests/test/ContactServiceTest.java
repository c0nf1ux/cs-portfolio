import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService contactService;
    private Contact testContact;
    
    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        testContact = new Contact("1234567890", "John", "Doe", "5551234567", "123 Main St");
    }
    
    @Test
    @DisplayName("Add contact successfully")
    public void testAddContact() {
        assertTrue(contactService.addContact(testContact));
        assertEquals(1, contactService.getContactCount());
        assertEquals(testContact, contactService.getContact("1234567890"));
    }
    
    @Test
    @DisplayName("Cannot add contact with duplicate ID")
    public void testAddDuplicateContact() {
        contactService.addContact(testContact);
        Contact duplicateContact = new Contact("1234567890", "Jane", "Smith", "5559876543", "456 Oak Ave");
        
        assertFalse(contactService.addContact(duplicateContact));
        assertEquals(1, contactService.getContactCount());
        assertEquals("John", contactService.getContact("1234567890").getFirstName());
    }
    
    @Test
    @DisplayName("Cannot add null contact")
    public void testAddNullContact() {
        assertFalse(contactService.addContact(null));
        assertEquals(0, contactService.getContactCount());
    }
    
    @Test
    @DisplayName("Delete contact successfully")
    public void testDeleteContact() {
        contactService.addContact(testContact);
        assertTrue(contactService.deleteContact("1234567890"));
        assertEquals(0, contactService.getContactCount());
        assertNull(contactService.getContact("1234567890"));
    }
    
    @Test
    @DisplayName("Cannot delete non-existent contact")
    public void testDeleteNonExistentContact() {
        assertFalse(contactService.deleteContact("9999999999"));
        assertEquals(0, contactService.getContactCount());
    }
    
    @Test
    @DisplayName("Cannot delete with null contact ID")
    public void testDeleteNullContactId() {
        contactService.addContact(testContact);
        assertFalse(contactService.deleteContact(null));
        assertEquals(1, contactService.getContactCount());
    }
    
    @Test
    @DisplayName("Update first name successfully")
    public void testUpdateFirstName() {
        contactService.addContact(testContact);
        assertTrue(contactService.updateFirstName("1234567890", "Jane"));
        assertEquals("Jane", contactService.getContact("1234567890").getFirstName());
    }
    
    @Test
    @DisplayName("Cannot update first name for non-existent contact")
    public void testUpdateFirstNameNonExistentContact() {
        assertFalse(contactService.updateFirstName("9999999999", "Jane"));
    }
    
    @Test
    @DisplayName("Cannot update first name with invalid value")
    public void testUpdateFirstNameInvalid() {
        contactService.addContact(testContact);
        assertFalse(contactService.updateFirstName("1234567890", null));
        assertFalse(contactService.updateFirstName("1234567890", "VeryLongName"));
        assertEquals("John", contactService.getContact("1234567890").getFirstName());
    }
    
    @Test
    @DisplayName("Update last name successfully")
    public void testUpdateLastName() {
        contactService.addContact(testContact);
        assertTrue(contactService.updateLastName("1234567890", "Smith"));
        assertEquals("Smith", contactService.getContact("1234567890").getLastName());
    }
    
    @Test
    @DisplayName("Cannot update last name for non-existent contact")
    public void testUpdateLastNameNonExistentContact() {
        assertFalse(contactService.updateLastName("9999999999", "Smith"));
    }
    
    @Test
    @DisplayName("Cannot update last name with invalid value")
    public void testUpdateLastNameInvalid() {
        contactService.addContact(testContact);
        assertFalse(contactService.updateLastName("1234567890", null));
        assertFalse(contactService.updateLastName("1234567890", "VeryLongName"));
        assertEquals("Doe", contactService.getContact("1234567890").getLastName());
    }
    
    @Test
    @DisplayName("Update phone successfully")
    public void testUpdatePhone() {
        contactService.addContact(testContact);
        assertTrue(contactService.updatePhone("1234567890", "5559876543"));
        assertEquals("5559876543", contactService.getContact("1234567890").getPhone());
    }
    
    @Test
    @DisplayName("Cannot update phone for non-existent contact")
    public void testUpdatePhoneNonExistentContact() {
        assertFalse(contactService.updatePhone("9999999999", "5559876543"));
    }
    
    @Test
    @DisplayName("Cannot update phone with invalid value")
    public void testUpdatePhoneInvalid() {
        contactService.addContact(testContact);
        assertFalse(contactService.updatePhone("1234567890", null));
        assertFalse(contactService.updatePhone("1234567890", "555123456"));
        assertFalse(contactService.updatePhone("1234567890", "555-123-4567"));
        assertEquals("5551234567", contactService.getContact("1234567890").getPhone());
    }
    
    @Test
    @DisplayName("Update address successfully")
    public void testUpdateAddress() {
        contactService.addContact(testContact);
        assertTrue(contactService.updateAddress("1234567890", "456 Oak Avenue"));
        assertEquals("456 Oak Avenue", contactService.getContact("1234567890").getAddress());
    }
    
    @Test
    @DisplayName("Cannot update address for non-existent contact")
    public void testUpdateAddressNonExistentContact() {
        assertFalse(contactService.updateAddress("9999999999", "456 Oak Avenue"));
    }
    
    @Test
    @DisplayName("Cannot update address with invalid value")
    public void testUpdateAddressInvalid() {
        contactService.addContact(testContact);
        assertFalse(contactService.updateAddress("1234567890", null));
        assertFalse(contactService.updateAddress("1234567890", 
            "This address is way too long and exceeds the thirty character limit"));
        assertEquals("123 Main St", contactService.getContact("1234567890").getAddress());
    }
    
    @Test
    @DisplayName("Multiple contacts can be managed")
    public void testMultipleContacts() {
        Contact contact1 = new Contact("1111111111", "John", "Doe", "5551111111", "111 First St");
        Contact contact2 = new Contact("2222222222", "Jane", "Smith", "5552222222", "222 Second St");
        
        assertTrue(contactService.addContact(contact1));
        assertTrue(contactService.addContact(contact2));
        assertEquals(2, contactService.getContactCount());
        
        assertTrue(contactService.updateFirstName("1111111111", "Jack"));
        assertTrue(contactService.updateLastName("2222222222", "Jones"));
        
        assertEquals("Jack", contactService.getContact("1111111111").getFirstName());
        assertEquals("Jones", contactService.getContact("2222222222").getLastName());
        
        assertTrue(contactService.deleteContact("1111111111"));
        assertEquals(1, contactService.getContactCount());
        assertNull(contactService.getContact("1111111111"));
        assertNotNull(contactService.getContact("2222222222"));
    }
}
