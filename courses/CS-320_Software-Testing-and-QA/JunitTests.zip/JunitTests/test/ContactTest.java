import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    
    @Test
    @DisplayName("Contact created successfully with valid parameters")
    public void testContactCreation() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5551234567", "123 Main St");
        
        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("5551234567", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
    
    @Test
    @DisplayName("Contact ID cannot be null")
    public void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Contact ID cannot be longer than 10 characters")
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("First name cannot be null")
    public void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "Doe", "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("First name cannot be longer than 10 characters")
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "VeryLongName", "Doe", "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Last name cannot be null")
    public void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", null, "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Last name cannot be longer than 10 characters")
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "VeryLongName", "5551234567", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Phone cannot be null")
    public void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", null, "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Phone must be exactly 10 digits")
    public void testPhoneInvalidLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "555123456", "123 Main St");
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "55512345678", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Phone must contain only digits")
    public void testPhoneNonDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "555-123-456", "123 Main St");
        });
    }
    
    @Test
    @DisplayName("Address cannot be null")
    public void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "5551234567", null);
        });
    }
    
    @Test
    @DisplayName("Address cannot be longer than 30 characters")
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "5551234567", 
                "This address is way too long and exceeds the limit");
        });
    }
    
    @Test
    @DisplayName("Contact fields can be updated with valid values")
    public void testContactFieldUpdates() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5551234567", "123 Main St");
        
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
        
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
        
        contact.setPhone("5559876543");
        assertEquals("5559876543", contact.getPhone());
        
        contact.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", contact.getAddress());
    }
    
    @Test
    @DisplayName("Contact ID is not updatable")
    public void testContactIdImmutable() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5551234567", "123 Main St");
        assertEquals("1234567890", contact.getContactId());
        // No setter method exists for contactId, ensuring immutability
    }
}
