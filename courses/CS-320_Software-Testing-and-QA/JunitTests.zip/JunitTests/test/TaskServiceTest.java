import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService;
    private Task testTask;
    
    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
        testTask = new Task("1234567890", "Test Task", "This is a test task description");
    }
    
    @Test
    @DisplayName("Add task successfully")
    public void testAddTask() {
        assertTrue(taskService.addTask(testTask));
        assertEquals(1, taskService.getTaskCount());
        assertEquals(testTask, taskService.getTask("1234567890"));
    }
    
    @Test
    @DisplayName("Cannot add task with duplicate ID")
    public void testAddDuplicateTask() {
        taskService.addTask(testTask);
        Task duplicateTask = new Task("1234567890", "Different Name", "Different description");
        
        assertFalse(taskService.addTask(duplicateTask));
        assertEquals(1, taskService.getTaskCount());
        assertEquals("Test Task", taskService.getTask("1234567890").getName());
    }
    
    @Test
    @DisplayName("Cannot add null task")
    public void testAddNullTask() {
        assertFalse(taskService.addTask(null));
        assertEquals(0, taskService.getTaskCount());
    }
    
    @Test
    @DisplayName("Delete task successfully")
    public void testDeleteTask() {
        taskService.addTask(testTask);
        assertTrue(taskService.deleteTask("1234567890"));
        assertEquals(0, taskService.getTaskCount());
        assertNull(taskService.getTask("1234567890"));
    }
    
    @Test
    @DisplayName("Cannot delete non-existent task")
    public void testDeleteNonExistentTask() {
        assertFalse(taskService.deleteTask("9999999999"));
        assertEquals(0, taskService.getTaskCount());
    }
    
    @Test
    @DisplayName("Cannot delete with null task ID")
    public void testDeleteNullTaskId() {
        taskService.addTask(testTask);
        assertFalse(taskService.deleteTask(null));
        assertEquals(1, taskService.getTaskCount());
    }
    
    @Test
    @DisplayName("Update task name successfully")
    public void testUpdateName() {
        taskService.addTask(testTask);
        assertTrue(taskService.updateName("1234567890", "Updated Task Name"));
        assertEquals("Updated Task Name", taskService.getTask("1234567890").getName());
    }
    
    @Test
    @DisplayName("Cannot update name for non-existent task")
    public void testUpdateNameNonExistentTask() {
        assertFalse(taskService.updateName("9999999999", "New Name"));
    }
    
    @Test
    @DisplayName("Cannot update name with invalid value")
    public void testUpdateNameInvalid() {
        taskService.addTask(testTask);
        assertFalse(taskService.updateName("1234567890", null));
        assertFalse(taskService.updateName("1234567890", "This name is way too long for requirements"));
        assertEquals("Test Task", taskService.getTask("1234567890").getName());
    }
    
    @Test
    @DisplayName("Update task description successfully")
    public void testUpdateDescription() {
        taskService.addTask(testTask);
        assertTrue(taskService.updateDescription("1234567890", "Updated task description"));
        assertEquals("Updated task description", taskService.getTask("1234567890").getDescription());
    }
    
    @Test
    @DisplayName("Cannot update description for non-existent task")
    public void testUpdateDescriptionNonExistentTask() {
        assertFalse(taskService.updateDescription("9999999999", "New Description"));
    }
    
    @Test
    @DisplayName("Cannot update description with invalid value")
    public void testUpdateDescriptionInvalid() {
        taskService.addTask(testTask);
        assertFalse(taskService.updateDescription("1234567890", null));
        assertFalse(taskService.updateDescription("1234567890", 
            "This description is way too long and exceeds the fifty character limit"));
        assertEquals("This is a test task description", taskService.getTask("1234567890").getDescription());
    }
    
    @Test
    @DisplayName("Multiple tasks can be managed")
    public void testMultipleTasks() {
        Task task1 = new Task("1111111111", "Task One", "First task description");
        Task task2 = new Task("2222222222", "Task Two", "Second task description");
        
        assertTrue(taskService.addTask(task1));
        assertTrue(taskService.addTask(task2));
        assertEquals(2, taskService.getTaskCount());
        
        assertTrue(taskService.updateName("1111111111", "Updated Task One"));
        assertTrue(taskService.updateDescription("2222222222", "Updated second task description"));
        
        assertEquals("Updated Task One", taskService.getTask("1111111111").getName());
        assertEquals("Updated second task description", taskService.getTask("2222222222").getDescription());
        
        assertTrue(taskService.deleteTask("1111111111"));
        assertEquals(1, taskService.getTaskCount());
        assertNull(taskService.getTask("1111111111"));
        assertNotNull(taskService.getTask("2222222222"));
    }
    
    @Test
    @DisplayName("Task service handles boundary values correctly")
    public void testBoundaryValues() {
        Task maxTask = new Task("1234567890", "12345678901234567890", 
            "12345678901234567890123456789012345678901234567890");
        
        assertTrue(taskService.addTask(maxTask));
        assertEquals("1234567890", taskService.getTask("1234567890").getTaskId());
        assertEquals("12345678901234567890", taskService.getTask("1234567890").getName());
        assertEquals("12345678901234567890123456789012345678901234567890", 
            taskService.getTask("1234567890").getDescription());
    }
    
    @Test
    @DisplayName("Get task returns null for non-existent ID")
    public void testGetNonExistentTask() {
        assertNull(taskService.getTask("9999999999"));
    }
}
