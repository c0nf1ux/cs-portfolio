import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    
    @Test
    @DisplayName("Task created successfully with valid parameters")
    public void testTaskCreation() {
        Task task = new Task("1234567890", "Task Name", "This is a task description");
        
        assertEquals("1234567890", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("This is a task description", task.getDescription());
    }
    
    @Test
    @DisplayName("Task ID cannot be null")
    public void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Description");
        });
    }
    
    @Test
    @DisplayName("Task ID cannot be longer than 10 characters")
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Description");
        });
    }
    
    @Test
    @DisplayName("Task name cannot be null")
    public void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "Description");
        });
    }
    
    @Test
    @DisplayName("Task name cannot be longer than 20 characters")
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is way too long", "Description");
        });
    }
    
    @Test
    @DisplayName("Task description cannot be null")
    public void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", null);
        });
    }
    
    @Test
    @DisplayName("Task description cannot be longer than 50 characters")
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Task Name", 
                "This description is way too long and exceeds the fifty character limit");
        });
    }
    
    @Test
    @DisplayName("Task name can be updated with valid value")
    public void testUpdateName() {
        Task task = new Task("1234567890", "Task Name", "Description");
        task.setName("New Task Name");
        assertEquals("New Task Name", task.getName());
    }
    
    @Test
    @DisplayName("Cannot update task name with null")
    public void testUpdateNameNull() {
        Task task = new Task("1234567890", "Task Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertEquals("Task Name", task.getName());
    }
    
    @Test
    @DisplayName("Cannot update task name with value too long")
    public void testUpdateNameTooLong() {
        Task task = new Task("1234567890", "Task Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is way too long");
        });
        assertEquals("Task Name", task.getName());
    }
    
    @Test
    @DisplayName("Task description can be updated with valid value")
    public void testUpdateDescription() {
        Task task = new Task("1234567890", "Task Name", "Description");
        task.setDescription("New description for the task");
        assertEquals("New description for the task", task.getDescription());
    }
    
    @Test
    @DisplayName("Cannot update task description with null")
    public void testUpdateDescriptionNull() {
        Task task = new Task("1234567890", "Task Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertEquals("Description", task.getDescription());
    }
    
    @Test
    @DisplayName("Cannot update task description with value too long")
    public void testUpdateDescriptionTooLong() {
        Task task = new Task("1234567890", "Task Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is way too long and exceeds the fifty character limit set by requirements");
        });
        assertEquals("Description", task.getDescription());
    }
    
    @Test
    @DisplayName("Task ID is not updatable")
    public void testTaskIdImmutable() {
        Task task = new Task("1234567890", "Task Name", "Description");
        assertEquals("1234567890", task.getTaskId());
        // No setter method exists for taskId, ensuring immutability
    }
    
    @Test
    @DisplayName("Task accepts maximum length values")
    public void testMaximumLengthValues() {
        Task task = new Task("1234567890", "12345678901234567890", 
            "12345678901234567890123456789012345678901234567890");
        
        assertEquals("1234567890", task.getTaskId());
        assertEquals("12345678901234567890", task.getName());
        assertEquals("12345678901234567890123456789012345678901234567890", task.getDescription());
    }
}
